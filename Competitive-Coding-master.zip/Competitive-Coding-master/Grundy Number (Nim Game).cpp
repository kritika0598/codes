//Problem 1 (Prefix Nim): https://codeforces.com/contest/88/problem/E
//Solution 1: https://codeforces.com/contest/88/submission/45960116
