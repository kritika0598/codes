//Problem 1 (Frequency Match): https://codeforces.com/contest/701/problem/C
//Solution 1: https://codeforces.com/contest/701/submission/45452242

//Problem 2 (Moving pointer when violating condition): https://codeforces.com/contest/514/problem/D
//Solution 2: https://codeforces.com/contest/514/submission/45492951
